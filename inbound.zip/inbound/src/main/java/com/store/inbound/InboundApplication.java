package com.store.inbound;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InboundApplication {

	public static void main(String[] args) {
		SpringApplication.run(InboundApplication.class, args);
	}

}
