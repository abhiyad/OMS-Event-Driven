package com.store.inbound;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InboundApplicationTests {

	@Test
	void contextLoads() {
	}

}
