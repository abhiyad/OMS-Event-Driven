package com.store.monitor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonitorApplicationTests {

	@Test
	void contextLoads() {
	}

}
